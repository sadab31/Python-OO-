marks=int(input("Enter your marks: "))
if marks>=90:
    print("A")
elif marks>=85:
    print("A-")
elif marks>=80:
    print("B+")
elif marks>=75:
    print("B")
elif marks>=70:
    print("B-")
elif marks>=65:
    print("C+")
elif marks>=60:
    print("C")
elif marks>=57:
    print("C-")
elif marks>=55:
    print("D+")
elif marks>=52:
    print("D")
elif marks>=50:
    print("D-")
else:
    print("F")