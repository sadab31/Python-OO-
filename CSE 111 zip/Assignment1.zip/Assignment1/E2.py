list=[]
for i in range(3):
    a=int(input())
    list.append(a)
list.sort()
print(list[len(list)-1])
