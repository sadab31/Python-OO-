n=int(input())
n=bin(n)
binary=""
for i in n:
    if i=="1":
        binary=binary+i
list=list(binary)
list.reverse()
sum=0
for i in range(len(list)):
    a=int(list[i])
    sum=sum+(a*(pow(2,i)))
print(sum)

