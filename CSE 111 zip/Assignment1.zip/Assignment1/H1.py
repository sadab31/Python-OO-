a=int(input())
list=[]
while a>0:
    b=a%10
    if b not in list:
        list.append(b)
    a=a//10

print(len(list))