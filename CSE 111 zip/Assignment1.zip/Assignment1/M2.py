a=int(input())
while a>0:
    print(a%10,end="")
    a=a//10