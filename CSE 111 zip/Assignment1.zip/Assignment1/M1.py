n=int(input("Enter a number : "))
first=0
second=1

print(first,end=" ")
print(second, end=" ")
while 1:
    temp=first

    first=second
    second=temp+second
    if second>n:
        break
    print(second, end=" ")
