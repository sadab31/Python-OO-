p=int(input())
count=0
for i in range(2,p):
    if p%i==0:
        count+=1
if count==0 or p==2:
    print("PRIME")
else:
    print("NOT PRIME")

