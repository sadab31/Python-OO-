n=int(input())

for i in range(1,n):

    for s in range(1,(n-i)+1):
        print(" ",end="")

    for t in range(1,(2*n)):
        if t==1 or t==2*i-1:
            print("*",end="")
        else:
            print(" ",end="")

    print(" ")

for i in range(2*n-1):
    print("*",end="")
print(" ")
for i in range(n-1,0,-1):
    for j in range(1,(n-i)+1):
        print(" ",end="")
    for t in range(1,2*n):
        if t==1 or t==(2*i)-1:
            print("*", end="")
        else:
            print(" ", end="")

    print(" ")


