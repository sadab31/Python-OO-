s=input()
a=s[0]
i=len(s)-1
while i>=0:
    if s[i]==a:
        break
    i-=1
t=""
j=i
while j<len(s):
    t=t+s[j]
    j+=1
length=len(t)
if s.startswith(t) and s.endswith(t):

    k=len(s)-length+1
    s=s[length:k]
    if t in s:
        print(t)
    else:
        print("Not Palindrome substring")
else:
    print("Not Palindrome substring")

