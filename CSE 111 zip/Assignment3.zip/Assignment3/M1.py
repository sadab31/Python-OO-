s=input()
upper=0
lower=0
for i in s:
    if ord(i)>=65 and ord(i)<=90:
        upper+=1
    elif ord(i)>=97 and ord(i)<=122:
        lower+=1
if upper>lower:
    print(s.upper())
else:
    print(s.lower())