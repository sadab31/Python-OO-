m=list(map(str,input().split()))
s=m[0]
p=m[1]
k=""

for i in s:
    if i in p:
        k=k+i
t=""
for i in p:
    if i in k:
        t=t+i

if len(k+t)>0:
    print(k+t)
else:
    print("Nothing in common")
