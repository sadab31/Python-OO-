s=input()
result=0
k=""
for i in s:
    if result==1:
        if ord(i) >= 65 and ord(i) <= 90:
            break
        else:
            k=k+i

    if ord(i)>=65 and ord(i)<=90:

        result=1

if len(k)>0:
    print(k)
else:
    print("BLANK")
