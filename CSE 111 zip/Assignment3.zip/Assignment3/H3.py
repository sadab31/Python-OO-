s=input()

lower=0
upper=0
digit=0
special=0

for i in s:
    a=ord(i)
    if a>=65 and a<=90:
        upper+=1
    elif a>=97 and a<=122:
        lower+=1
    elif a>=49 and a<=57:
        digit+=1
    else:
        special+=1

t=""
if lower>0 and upper>0 and digit>0 and special>0:
    print("OK")
else:
    if lower==0:
        t=t+"Lowercase character missing, "
    if upper ==0:
        t=t+"Uppercase character missing, "
    if digit==0:
        t=t+"Digit missing, "
    if special==0:
        t=t+"Special character missing, "
print(t[:-2])