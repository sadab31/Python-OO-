s=input()
if len(s)<4:
    print(s)
else:
    if s.endswith("ful"):
        print(s+"ly")
    else:
        print(s+"ful")