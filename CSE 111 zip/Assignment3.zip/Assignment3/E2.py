s=input()
k=""
for i in range(len(s)-1,-1,-1):
    k=k+s[i]
if k==s:
    print("True")
else:
    print("False")