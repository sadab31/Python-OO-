s=input()
if s.find("too")<s.find("good"):

    s=s.replace("too good","excellent")
print(s)