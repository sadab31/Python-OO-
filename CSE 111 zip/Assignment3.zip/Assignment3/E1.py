s=input()
k=""
count=0
for i in s:
    if i=="a" or i=="e" or i=="i" or i=="o" or i=="u":
       count+=1
    else:
        k=k+i
print(k+str(count))