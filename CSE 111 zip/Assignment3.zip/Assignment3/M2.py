s=input()
num=0
lett=0

for i in s:
    a=ord(i)
    if (a>=65 and a<=90) or (a>=97 and a<=122):
        lett+=1
    elif a>=48 and a<=57:
        num+=1
if lett==0:
    print("NUMBER")
elif num==0:
    print("WORD")
else:
    print("MIXED")