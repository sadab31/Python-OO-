class Account:
    def __init__(self, balance):
        self._balance = balance

    def getBalance(self):
        return self._balance


class CheckingAccount(Account):
    numberOfAccount = '0'
    count = 0

    def __init__(self, bal=0):

        super().__init__(float(bal))
        CheckingAccount.count += 1
        CheckingAccount.numberOfAccount = str(CheckingAccount.count)

    def __str__(self):
        temp = ("Account Balance: " + str(self.getBalance()))
        return temp


print('Number of Checking Accounts: ' + CheckingAccount.numberOfAccount)
print(CheckingAccount())
print(CheckingAccount(100.00))
print(CheckingAccount(200.00))
print('Number of Checking Accounts: ' + CheckingAccount.numberOfAccount)
