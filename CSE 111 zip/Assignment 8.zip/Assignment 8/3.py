class RealNumber:
    def __init__(self, r=0):
        self.__realValue = r
    def getRealValue(self):
        return self.__realValue
    def setRealValue(self, r):
        self.__realValue = r
    def ping(self):
        print('I am in RealNumber class')
    def __str__(self):
        return 'RealPart: '+str(self.getRealValue())

class ComplexNumber(RealNumber):

    def __init__(self,r=None,i=None):
        if r==None and i==None:
            real=1.0
            img=1.0
        else:
            real=float(r)
            img=float(i)
        self.setRealValue(real)
        self.setimaginaryValue(img)

    def __str__(self):
        return "RealPart: {real}\nImaginaryPart: {imaginary}".format(real=str(self.getRealValue()),imaginary=str(self.__ImgValue))




    def setimaginaryValue(self, i):
        self.__ImgValue = i







cn1 = ComplexNumber()
print(cn1)
print('---------')
cn2 = ComplexNumber(5,7)
print(cn2)
print('---------')