s=input()
s=s.split(", ")
dic={}

for i in s:
    i=i.split(": ")
    dic[i[0]]=int(i[1])

max=0
min=0

for i in dic:
    max=dic[i]
    min=dic[i]
    break

maxI=""
minI=""


for i in dic:
    if dic[i]>=max:
        max=dic[i]
        maxI=i
    elif dic[i]<=min:
        min=dic[i]
        minI=i
print("Minimum: ",minI)
print("Maximum: ",maxI)