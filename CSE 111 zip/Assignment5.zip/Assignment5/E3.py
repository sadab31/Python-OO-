dic={"a":"b"}
k=1
t=10
i=1
while i <=t:
    k+=1
    n=int(input())
    count=0

    for j in dic:
        if dic[j]==n:
            count+=1
    if count!=0:
        print("Enter another number sir")
        t+=1
    else:
        dic[k]=n
    i+=1

