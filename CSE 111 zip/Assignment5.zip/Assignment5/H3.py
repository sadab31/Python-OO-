dic = {0: " ", 1: ".,?!:", 2: "ABC", 3: "DEF", 4: "GHI", 5: "JKL", 6: "MNO", 7: "PQRS", 8: "TUV", 9: "WXYZ"}
s = input()
s=s.upper()
m = ""

for i in s:
    a = ord(i)
    if a >= 65 and a <= 67:
        key = 2
        p = dic[key]
        idx = 1
        for j in p:
            if j == i:
                break
            else:
                idx += 1
        m = m + idx * str(key)
        print(m)

    elif a >= 68 and a <= 70:
        key = 3
        p = dic[key]
        idx = 1
        for j in p:
            if j == i:
                break
            else:
                idx += 1
        m = m + idx * str(key)

    elif a >= 71 and a <= 73:
        key = 4
        p = dic[key]
        idx = 1
        for j in p:
            if j == i:
                break
            else:
                idx += 1
        m = m + idx * str(key)

    elif a >= 74 and a <= 76:
        key = 5
        p = dic[key]
        idx = 1
        for j in p:
            if j == i:
                break
            else:
                idx += 1
        m = m + idx * str(key)

    elif a >= 77 and a <= 79:
        key = 6
        p = dic[key]
        idx = 1
        for j in p:
            if j == i:
                break
            else:
                idx += 1
        m = m + idx * str(key)

    elif a >= 80 and a <= 83:
        key = 7
        p = dic[key]
        idx = 1
        for j in p:
            if j == i:
                break
            else:
                idx += 1
        m = m + idx * str(key)

    elif a >= 84 and a <= 86:
        key = 8
        p = dic[key]
        idx = 1
        for j in p:
            if j == i:
                break
            else:
                idx += 1
        m = m + idx * str(key)

    elif a >= 87 and a <= 90:
        key = 9
        p = dic[key]
        idx = 1
        for j in p:
            if j == i:
                break
            else:
                idx += 1
        m = m + idx * str(key)

    elif a == 32:
        key = 0
        p = dic[key]
        idx = 1
        for j in p:
            if j == i:
                break
            else:
                idx += 1
        m = m + idx * str(key)

    else:
        key = 1
        p = dic[key]
        idx = 1
        for j in p:
            if j == i:
                break
            else:
                idx += 1
        m = m + idx * str(key)

print(m)
if int(m)==4433555555666110966677755531111:
    print("HO BHAI MILSEEEEEEE")