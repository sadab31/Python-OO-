mainlist=[]
while 1:
    a=input()
    if a=="STOP":
        break
    a=int(a)
    mainlist.append(a)

lx=[]
dic={}
for i in mainlist:
    if i not in lx:
        lx.append(i)
        dic[i]=1
    else:
        dic[i]=dic[i]+1

for i in dic:
    print(i,"-",dic[i],"times")