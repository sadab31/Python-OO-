s=input()
s=s.split(", ")
dic={}
for i in s:
    dic[i[0]]=int(i[3:])


while 1:
    a=input()
    if a=="STOP":
        break
    a=int(a)
    tcount=0
    for i in dic:

        if dic[i]==a:
            tcount+=1
    if tcount!=0:
        print("True")
    else:
        print("False")

