s = input()
p = input()
a = []
b = []
dic1 = {}
dic2 = {}

for i in s:

    if i not in a:
        a.append(i)
        dic1[i] = 1
    else:
        dic1[i] += 1

for i in p:

    if i not in b:
        b.append(i)
        dic2[i] = 1
    else:
        dic2[i] += 1
print(dic1)
print(dic2)
print(a, b)
count = 0
if len(dic1) == len(dic2):
    for j in a:
        if j in a and j in b:
            if dic1[j] == dic2[j]:
                count += 1
    if count == len(dic1):
        print("Those strings are anagrams")
    else:
        print("Those strings are not anagrams")
else:
    print("Those strings are not anagrams")
