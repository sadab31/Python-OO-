key1 = []
key2 = []

s = input()
s = s.split(", ")
dic1 = {}
for i in s:
    dic1[i[0]] = int(i[3:])
    key1.append(i[0])

p = input()
p = p.split(", ")
dic2 = {}
for i in p:
    dic2[i[0]] = int(i[3:])
    key2.append(i[0])

listx = []

for i in dic1:
    for j in dic2:
        if i == j:
            listx.append(i)

dic3 = {}

for i in listx:
    dic3[i] = dic2[i] + dic1[i]

for i in listx:
    if i in key1:
        key1.remove(i)
    if i in key2:
        key2.remove(i)

for i in key1:
    dic3[i] = dic1[i]
for i in key2:
    dic3[i] = dic2[i]

print(dic3)

tuplelist = []
for i in dic3:
    if dic3[i] not in tuplelist:
        tuplelist.append(dic3[i])
tuplelist.sort()
print("Value: ", tuple(tuplelist))
