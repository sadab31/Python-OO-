s=input()
key=[]
value=[]
s=s.split(", ")

for i in s:
    i=i.split(" : ")
    key.append(i[0])
    value.append(i[1])



dic={}
i=0
k=0
temp=[]
while i<len(key):
    if value[i] not in temp:
        temp.append(value[i])

        m = []
        m.append(key[i])

        j = i + 1
        while j < len(value):
            if value[i] == value[j]:
                m.append(key[j])
            j += 1

        dic[value[i]] = m
        i += 1
    else:
        i+=1


print(dic)



