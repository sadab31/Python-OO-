class Dates:
    def __init__(self,a):
        self.date=a

    @classmethod
    def toDashDate(cls,date):
        datex=date.split("/")
        datex="-".join(datex)
        datex=Dates(datex)
        return datex


    def getDate(self):
        return self.date

date1 = Dates("05-09-2020")
dateFromDB = "05/09/2020"
date2= Dates.toDashDate(dateFromDB)

if(date1.getDate() == date2.getDate() ):
    print("Equal")
else:
    print("Unequal")

#We have used the class method to convert a date seperated by '/' to '-'. Therefore the dates stored in both of the instances become same.
#We used the getDate method to compare. Therefore, the program prints equal.