class Joker:
    def __init__(self,name,power, is_he_psycho):
        self.name=name
        self.power=power
        self.is_he_psycho=is_he_psycho

j1 = Joker('Heath Ledger', 'Mind Game', False)
print(j1.name)
print(j1.power)
print(j1.is_he_psycho)
print('=====================')
j2 = Joker('Joaquin Phoenix', 'Laughing out Loud', True)
print(j2.name)
print(j2.power)
print(j2.is_he_psycho)
print('=====================')
if j1 == j2:
    print('same')
else:
    print('different')
j2.name = 'Heath Ledger'
if j1.name == j2.name:
    print('same')
else:
    print('different')

print('=====================')


print("They are different objects and that's why they allocate different memory locations. Here, j1 and j2 are just a reference of the main location. As the locations are different, the objects are also different")
print("Before the second if block the name variable of the 2nd object, j2 is changed to the name variable of the girst object. Thats why the logic says they are same. ")