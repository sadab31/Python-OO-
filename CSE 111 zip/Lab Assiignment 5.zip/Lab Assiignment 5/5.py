class Pokemon:
    def __init__(self, P1name,P2name,P1Power,P2Power,Combined):
        self.pokemon1_name=P1name
        self.pokemon2_name=P2name
        self.pokemon1_power=P1Power
        self.pokemon2_power=P2Power
        self.damage_rate=Combined

team_pika = Pokemon('pikachu', 'charmander', 90, 60, 10)
print('=======Team 1=======')
print('Pokemon 1:',team_pika.pokemon1_name,
team_pika.pokemon1_power)

print('Pokemon 2:',team_pika.pokemon2_name,
team_pika.pokemon2_power)
pika_combined_power = (team_pika.pokemon1_power +
team_pika.pokemon2_power) * team_pika.damage_rate
print('Combined Power:', pika_combined_power)




team_bulb=Pokemon('bulbasaur', 'squirtle', 80, 70,9)
print('=======Team 2=======')
print('Pokemon 1:',team_bulb.pokemon1_name,
team_bulb.pokemon1_power)

print('Pokemon 2:',team_bulb.pokemon2_name,
team_bulb.pokemon2_power)
bulb_combined_power = (team_bulb.pokemon1_power +
team_bulb.pokemon2_power) * team_bulb.damage_rate
print('Combined Power:', bulb_combined_power)
