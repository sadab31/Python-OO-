class Customer:
    def __init__(self,name):
        self.name=name


    def greet(self,a=None):
        if (a==None):
            print("Hello!")
        else:
            print("Hello",a,"!")


    def purchase(self,*args):
        length=len(args)
        print(self.name+", you purchased",length,"item(s)")
        for i in args:
            print(i)




customer_1=Customer("Sam")
customer_1.greet()
customer_1.purchase("chips", "chocolate", "orange juice")
print("-----------------------------")
customer_2 = Customer("David")
customer_2.greet("David")
customer_2.purchase("orange juice")
