class Calculator:
    def __init__(self):
        print("Lets Calculate!")


    def add(self,a,c,b):
        print("Value1: ",a)
        print("Operator:", c)
        print("Value2: ", b)
        print("Result: ", a+b)

    def subtract(self,a,c,b):
        print("Value1: ",a)
        print("Operator:", c)
        print("Value2: ", b)
        print("Result: ", a-b)


    def multiply(self,a,c,b):
        print("Value1: ",a)
        print("Operator:", c)
        print("Value2: ", b)
        print("Result: ", a*b)



    def divide(self,a,c,b):
        print("Value1: ",a)
        print("Operator:", c)
        print("Value2: ", b)
        print("Result: ", a//b)


ob1=Calculator()

a=int(input())
c=input()
b=int(input())

if c=="+":
    ob1.add(a,c,b)
elif c=="-":
    ob1.subtract(a,c,b)
elif c=="*":
    ob1.multiply(a,c,b)
elif c=="/":
    ob1.divide(a,c,b)