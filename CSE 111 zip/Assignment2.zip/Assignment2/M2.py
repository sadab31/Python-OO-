def replace_domain(e,n,o="sheba.xyz"):
    if "sheba.xyz" in e:
        e="Unchanged: "+e
        return e
    else:
        l=e.split("@")
        new="Changed: "+l[0]+"@"+n
        return new
a="bob@shexa.xyz"
b="sheba.xyz"
c="kaaj.com"
print(replace_domain(a,b,c))