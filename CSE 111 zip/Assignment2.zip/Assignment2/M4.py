#M4
def palindrome(a=""):
    list=a.split()

    temp=""
    for i in list:
        temp=temp+i

    if temp==temp[::-1]:
        return "Palindrome"
    else:
        return "Not a Palindrome"

a="nurses run"
print(palindrome(a))