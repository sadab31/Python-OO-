#M1
def chillox(burger,loc="Mohakhali"):
    if burger=="BBQ Chicken Cheese Burger":
        if loc!="Mohakhali":
            return 250+(8/100)*250+60
        else:
            return 250 + (8 / 100) * 250 + 40

    if burger=="Beef Burger":
        if loc!="Mohakhali":
            return 170+(8/100)*170+60
        else:
            return 170 + (8 / 100) * 170 + 40

    if burger=="Naga Drums":
        if loc!="Mohakhali":
            return 200+(8/100)*200+60
        else:
            return 200 + (8 / 100) * 200 + 40


print(chillox("Beef Burger"))