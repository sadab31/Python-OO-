#E3
def addition(min,max,div):
    sum=0
    for i in range(min,max):
        if i % div==0:
            sum=sum+i
    return sum

a=int(input())
b=int(input())
c=int(input())
print(addition(a,b,c))