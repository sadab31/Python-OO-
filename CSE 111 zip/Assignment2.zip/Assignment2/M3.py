#M3
def Vowels(a):
    temp=""
    sum=0
    for i in a:
        if i=="a" or i=="A" or i=="e" or i=="E" or i=="i" or i=="I" or i=="o" or i=="O" or i=="u" or i=="U":
            sum=sum+1
            temp=temp+i+","
    if sum!=0:
        print("Vowels: "+temp[:-1]+". Total number of vowels: "+str(sum))
    else:
        print("No vowels in the name")
a="Sadab"
Vowels(a)
