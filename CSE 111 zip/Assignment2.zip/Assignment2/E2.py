#E2

def BMI(height,weight):
    height=height/100
    Bmi=weight/(height*height)
    Bmi=round(Bmi,1)
    s=""
    cond=""
    if Bmi<18.5:
        cond="Underweight"
    elif Bmi<25:
        cond="Normal"
    elif Bmi<30.1:
        cond="Overweight"
    else:
        cond="Obese"
    s="Score is "+str(Bmi)+". You are "+cond

    return s
print(BMI(152,48))