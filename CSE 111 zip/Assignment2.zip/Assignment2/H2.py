# H2
#def year(a):
#   a = a % 365
 #   m = a // 30
  # print(str(y) + " years, " + str(m) + " months, " + str(d) + " days")


#year(4000)

day = int(input())

year = day // 365
remaining_days = day % 365

months = remaining_days // 30
remaining_days_2 = remaining_days % 30
days = remaining_days_2

print(year,months,days)
