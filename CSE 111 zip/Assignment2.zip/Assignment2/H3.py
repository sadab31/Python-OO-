
#H3

def String(s=""):

    k=""
    i=0
    s=list(s)
    while i<len(s):
        if s[i]=="." or s[i]=="," or s[i]=="?":
            if i+2<len(s):
                s[i+2]=s[i+2].upper()
        if i==0:
            s[0]=s[0].upper()
        if s[i]=="i" and s[i-1]==" " and s[i+1]==" ":
            s[i]=s[i].upper()
        k=k+s[i]
        i+=1
    return k
p='''my favourite animal is a dog. a dog has sharp teeth so that it can eat flesh very easily. do you know my pet dog’s name? i love my pet very much.'''

print(String(p))
