#H1
from datetime import date
year = date.today().year



def salary(*list):
    s = ""
    sal=0
    i = 0
    while i < len(list):
        yearlist=list[i+2].split("-")
        y=int(yearlist[0])
        if(year-y)<5:
            sal=(10/100)*int(list[i+1])
            sal=int(sal)
        elif (year-y)<11:
            sal=(10/100)*int(list[i+1])+5000
            sal=int(sal)
        else:
            sal=(15 / 100) * int(list[i + 1])+15000
            sal=int(sal)
        s=s+list[i]+": "+str(sal)+","

        i += 3
    return s[:-2]

print(salary("Alice",20000,"2017-03-1","Bob",50000,"2007-04-03","Sadab",100000,"2006-2-8"))