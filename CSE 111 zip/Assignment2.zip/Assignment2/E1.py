#E1

def fraction(a,b):
    if b==0 or a==0:
        return 0
    else:
        temp=a//b
        return a/b-temp
a=int(input())
b=int(input())
print(fraction(a,b))