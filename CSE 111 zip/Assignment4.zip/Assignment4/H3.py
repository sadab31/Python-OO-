list1=input()
list1=list1.split(" ")
list2=input()
list2=list2.split(" ")
a=int(list1[1])


count=0
for i in list2:
    if int(i)+a <= 5:
        count+=1
print(count//3)
