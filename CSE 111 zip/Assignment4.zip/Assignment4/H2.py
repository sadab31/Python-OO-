s=input()
lower=""
upper=""
digit=""

for i in s:
    a=ord(i)
    if a >=65 and a<=90:
        upper=upper+i
    elif a>=97 and a<=122:
        lower=lower+i
    else:
        digit=digit+i

odd=""
even=""
for i in digit:
    if int(i)%2==0:
        even=even+i
    else:
        odd=odd+i
temp=sorted(lower)
lower="".join(temp)
temp=sorted(upper)
upper="".join(temp)
temp=sorted(odd)
odd="".join(temp)
temp=sorted(even)
even="".join(temp)
print(lower+upper+odd+even)
