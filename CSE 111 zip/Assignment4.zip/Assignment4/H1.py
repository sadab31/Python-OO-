
temp=[]

while 1:

    a=input()
    if a=="STOP":
        break
    a=a.split(" ")
    i=0
    n=len(a)-1
    count=0
    while i < n:
        if abs(int(a[i])-int(a[i+1]))<=n:
            count+=1
        i+=1

    if count==n:
        print("UB Jumper")
    else:
        print("Not UB Jumper")

