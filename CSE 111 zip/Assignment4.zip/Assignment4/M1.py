list=[]
while 1:
    a=input()
    if a=="STOP":
        break
    a=int(a)
    list.append(a)

list2=[]
for i in list:
    if i not in list2:
        print(str(i)+"-"+str(list.count(i))+"times")
        list2.append(i)