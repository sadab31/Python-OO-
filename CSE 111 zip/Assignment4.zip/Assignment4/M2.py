n=int(input())
k=[]
for i in range(n):
    a=input()
    a=a.split(" ")
    k.append(a)

list2=[]




max=0
temp=0

for i in k:
    for j in i:
        list2.append(int(j))




    if sum(list2)>=max:
        max=sum(list2)
        temp=i
    list2=[]






print(max)
print(temp)
