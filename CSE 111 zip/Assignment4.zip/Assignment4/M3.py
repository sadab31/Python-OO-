a=input()
a=a.split(" ")
b=input()
b=b.split(" ")

c=[]

for i in a:
    for j in b:
        c.append(int(i)*int(j))
print(c)