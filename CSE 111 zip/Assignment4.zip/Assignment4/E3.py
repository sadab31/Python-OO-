list=[]
i=1
while i<=10:

    a=int(input())
    if a in list:
        print("Enter another number sir ")
        i-=1
    else:
        list.append(a)
    i+=1