n=int(input())
s=input()
char=s.split(",")
list=[]

for i in range(n):

    list.append(i)

i=0
while i<n:
    list[i]=[]
    i+=1

temp=0
j=0
for i in list:
    j=temp

    while j<len(char):

        i.append(char[j])
        j+=3
    temp+=1
print(list)
