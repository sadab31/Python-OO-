s=input()
p=input()
list1=s.split(",")
list2=p.split(",")
list1=list1[:-1]
list1=list1+list2
list=[]
for i in list1:
    list.append(int(i))
print(list)