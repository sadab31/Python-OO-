list=[]
for i in range(10):
    a=int(input())
    list.append(a)
list.reverse()
for i in list:
    print(i)